package com.google;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
