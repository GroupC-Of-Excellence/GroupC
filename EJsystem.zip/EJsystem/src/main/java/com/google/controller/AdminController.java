package com.google.controller;

public class AdminController {
}
